# add your get-notes function here

import boto3
from boto3.dynamodb.conditions import Key

#create a dynamodb resource
dynamodb_resource = boto3.resource('dynamodb')
#create a table object
table = dynamodb_resource.Table('notes')

def lambda_handler(email):
    return table.query(KeyConditionExpression=Key("email").eq(email))

    
    