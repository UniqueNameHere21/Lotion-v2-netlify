# add your delete-note function here
def handler(event, context):
    print("TEST TEST TEST!!!")